import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class VerificationService {
  constructor(private readonly http: HttpClient) {}

  getSettings(guildId: number): Promise<any> {
    return firstValueFrom(
      this.http.get(
        `/api/v1/discord/guilds/${guildId}/verification/settings`,
      ),
    );
  }

  saveSettings(
    guildId: number,
    payload: any,
  ): Promise<any> {
    return firstValueFrom(
      this.http.put(
        `/api/v1/discord/guilds/${guildId}/verification/settings`,
        payload,
      ),
    );
  }

  listRequests(
    guildId: number,
    status?: string,
  ): Promise<any> {
    const suffix = status
      ? `?status=${encodeURIComponent(status)}`
      : '';

    return firstValueFrom(
      this.http.get(
        `/api/v1/discord/guilds/${guildId}/verification/requests${suffix}`,
      ),
    );
  }

  approve(
    guildId: number,
    requestId: string,
    reason: string | null,
  ): Promise<any> {
    return firstValueFrom(
      this.http.post(
        `/api/v1/discord/guilds/${guildId}/verification/requests/${requestId}/approve`,
        { reason },
      ),
    );
  }

  reject(
    guildId: number,
    requestId: string,
    reason: string,
  ): Promise<any> {
    return firstValueFrom(
      this.http.post(
        `/api/v1/discord/guilds/${guildId}/verification/requests/${requestId}/reject`,
        { reason },
      ),
    );
  }
  retry(
    guildId: number,
    requestId: string,
  ): Promise<any> {
    return firstValueFrom(
      this.http.post(
        `/api/v1/discord/guilds/${guildId}/verification/requests/${requestId}/retry`,
        {},
      ),
    );
  }

  summary(guildId: number): Promise<any> {
    return firstValueFrom(this.http.get(`/api/v1/discord/guilds/${guildId}/verification/summary`));
  }

  cancel(guildId: number, requestId: string): Promise<any> {
    return firstValueFrom(this.http.post(`/api/v1/discord/guilds/${guildId}/verification/requests/${requestId}/cancel`, {}));
  }

  requeue(guildId: number, requestId: string): Promise<any> {
    return firstValueFrom(this.http.post(`/api/v1/discord/guilds/${guildId}/verification/requests/${requestId}/requeue`, {}));
  }

  resendReview(guildId: number, requestId: string): Promise<any> {
    return firstValueFrom(this.http.post(`/api/v1/discord/guilds/${guildId}/verification/requests/${requestId}/resend-review`, {}));
  }

  bulkCancel(
    guildId: number,
    requestIds: string[],
  ): Promise<any> {
    return firstValueFrom(
      this.http.post(
        `/api/v1/discord/guilds/${guildId}/verification/bulk/cancel`,
        { request_ids: requestIds },
      ),
    );
  }

  bulkRequeue(
    guildId: number,
    requestIds: string[],
  ): Promise<any> {
    return firstValueFrom(
      this.http.post(
        `/api/v1/discord/guilds/${guildId}/verification/bulk/requeue`,
        { request_ids: requestIds },
      ),
    );
  }

  recoverStale(
    guildId: number,
    olderThanMinutes: number,
  ): Promise<any> {
    return firstValueFrom(
      this.http.post(
        `/api/v1/discord/guilds/${guildId}/verification/recover-stale`,
        { older_than_minutes: olderThanMinutes },
      ),
    );
  }

  requestChanges(guildId: number, requestId: string, reason: string): Promise<any> {
    return firstValueFrom(this.http.post(`/api/v1/discord/guilds/${guildId}/verification/requests/${requestId}/request-changes`, { reason }));
  }

  history(guildId: number, requestId: string): Promise<any> {
    return firstValueFrom(this.http.get(`/api/v1/discord/guilds/${guildId}/verification/requests/${requestId}/history`));
  }

  exportUrl(
    guildId: number,
    status?: string,
  ): string {
    const suffix = status
      ? `?status=${encodeURIComponent(status)}`
      : '';

    return `/api/v1/discord/guilds/${guildId}/verification/export.csv${suffix}`;
  }

}
