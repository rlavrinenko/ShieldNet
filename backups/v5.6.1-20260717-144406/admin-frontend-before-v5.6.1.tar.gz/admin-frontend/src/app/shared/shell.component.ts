import { Component, Input, computed } from '@angular/core';
import { ActivatedRoute, RouterLink, RouterLinkActive } from '@angular/router';

import { AuthService } from '../core/auth.service';

@Component({
  selector: 'sn-shell',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  template: `
    <div class="shell">
      <aside class="sidebar">
        <a routerLink="/" class="brand">
          <span class="brand-mark">S</span>
          <span>ShieldNet</span>
        </a>

        <nav>
          <div class="nav-caption">Platform</div>
          <a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{ exact: true }">Dashboard</a>

          @if (guildId()) {
            <div class="nav-caption">Current server</div>
            <a [routerLink]="['/guild', guildId()]" routerLinkActive="active" [routerLinkActiveOptions]="{ exact: true }">Server overview</a>
            <a [routerLink]="['/guild', guildId(), 'explorer']" routerLinkActive="active">Discord Explorer</a>
            <a [routerLink]="['/guild', guildId(), 'permission-simulator']" routerLinkActive="active">Permission Simulator</a>
            <a [routerLink]="['/guild', guildId(), 'server-diff']" routerLinkActive="active">Server Diff</a>
            <a [routerLink]="['/guild', guildId(), 'backups']" routerLinkActive="active">Backup Center</a>
            <a [routerLink]="['/guild', guildId(), 'automations']" routerLinkActive="active">Automation Designer</a>
            <a [routerLink]="['/guild', guildId(), 'automation-monitor']" routerLinkActive="active">Automation Monitor</a>
            <a [routerLink]="['/guild', guildId(), 'workflow-scheduler']" routerLinkActive="active">Workflow Scheduler</a>
            <a [routerLink]="['/guild', guildId(), 'members']" routerLinkActive="active">Members</a>
            <a [routerLink]="['/guild', guildId(), 'moderation']" routerLinkActive="active">Moderation</a>
            <a [routerLink]="['/guild', guildId(), 'verification']" routerLinkActive="active">Verification</a>
            <a [routerLink]="['/guild', guildId(), 'leadership']" routerLinkActive="active">R5/R4 Applications</a>
            <a [routerLink]="['/guild', guildId(), 'permissions']" routerLinkActive="active">Permissions</a>
            <a [routerLink]="['/guild', guildId(), 'security']" routerLinkActive="active">Security</a>
            <a [routerLink]="['/guild', guildId(), 'audit']" routerLinkActive="active">Audit log</a>
            <a [routerLink]="['/guild', guildId(), 'control']" routerLinkActive="active">Server control</a>
          } @else {
            <a routerLink="/">My servers</a>
          }

          @if (auth.profile()?.is_superadmin) {
            <div class="nav-caption">Global administration</div>
            <a routerLink="/platform/access" routerLinkActive="active">Platform access</a>
            <a routerLink="/platform/jobs" routerLinkActive="active">Jobs & health</a>
            <a routerLink="/platform/operations" routerLinkActive="active">Live operations</a>
            <a routerLink="/platform/notifications" routerLinkActive="active">Notifications</a>
            <a routerLink="/platform/doctor" routerLinkActive="active">ShieldNet Doctor</a>
          }
        </nav>

        <div class="sidebar-footer">
          <div class="status"><span></span> Platform online</div>
          <button class="logout" (click)="auth.logout()">Logout</button>
        </div>
      </aside>

      <main>
        <header>
          <div>
            <div class="muted">ShieldNet Console</div>
            <h1>{{ title }}</h1>
          </div>
          <div class="user">
            <span>{{ auth.profile()?.display_name || auth.profile()?.login }}</span>
            @if (auth.profile()?.is_superadmin) { <b>SuperAdmin</b> }
          </div>
        </header>

        <section class="content"><ng-content /></section>
      </main>
    </div>
  `,
  styles: [`
    .shell { min-height:100vh; display:grid; grid-template-columns:260px minmax(0,1fr); }
    .sidebar { position:sticky; top:0; height:100vh; padding:1.2rem; background:rgba(8,12,23,.9); border-right:1px solid var(--line); display:flex; flex-direction:column; backdrop-filter:blur(18px); overflow:auto; }
    .brand { display:flex; align-items:center; gap:.8rem; font-weight:800; font-size:1.12rem; padding:.6rem; }
    .brand-mark { display:grid; place-items:center; width:2.2rem; height:2.2rem; border-radius:11px; background:linear-gradient(135deg,var(--primary),#9a64ff); box-shadow:0 10px 30px rgba(104,119,255,.35); }
    nav { display:grid; gap:.25rem; margin-top:1.6rem; }
    .nav-caption { margin:1rem .9rem .35rem; color:var(--muted); font-size:.68rem; font-weight:800; letter-spacing:.1em; text-transform:uppercase; }
    nav a { padding:.72rem .9rem; border-radius:11px; color:var(--muted); display:flex; align-items:center; border:1px solid transparent; }
    nav a:hover { color:var(--text); background:var(--primary-soft); }
    nav a.active { color:var(--text); background:var(--primary-soft); border-color:rgba(122,133,255,.22); }
    .sidebar-footer { margin-top:auto; display:grid; gap:1rem; padding-top:1.2rem; }
    .status { color:var(--muted); font-size:.78rem; display:flex; align-items:center; gap:.45rem; }
    .status span { width:.55rem; height:.55rem; border-radius:50%; background:#74e9b3; box-shadow:0 0 12px #74e9b3; }
    .logout { background:transparent; color:var(--muted); text-align:left; padding:0; }
    main { min-width:0; }
    header { min-height:90px; padding:1.2rem 2rem; display:flex; align-items:center; justify-content:space-between; border-bottom:1px solid var(--line); background:rgba(8,12,23,.58); backdrop-filter:blur(18px); }
    h1 { margin:.25rem 0 0; font-size:1.45rem; }
    .user { border:1px solid var(--line); border-radius:999px; padding:.55rem .85rem; color:var(--muted); display:grid; gap:.1rem; }
    .user b { color:#cfd5ff; font-size:.66rem; text-transform:uppercase; }
    .content { padding:2rem; }
    @media (max-width:900px) { .shell{grid-template-columns:1fr}.sidebar{position:static;height:auto;overflow:visible}.sidebar nav{display:flex;overflow:auto;gap:.35rem}.nav-caption{display:none}.sidebar-footer{display:none}.brand{margin-bottom:.5rem}header{padding:1rem}.content{padding:1rem}nav a{white-space:nowrap} }
  `],
})
export class ShellComponent {
  @Input({ required: true }) title = '';

  readonly guildId = computed(() => {
    let route: ActivatedRoute | null = this.route;
    while (route) {
      const value = route.snapshot.paramMap.get('guildId');
      if (value) return value;
      route = route.parent;
    }
    return null;
  });

  constructor(public readonly auth: AuthService, private readonly route: ActivatedRoute) {}
}
