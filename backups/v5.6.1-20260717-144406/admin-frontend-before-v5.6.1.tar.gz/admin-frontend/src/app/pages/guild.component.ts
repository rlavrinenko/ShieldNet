import { Component, OnInit, computed, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';

import { GuildAccess } from '../core/api.models';
import { GuildService } from '../core/guild.service';
import { GuildModule } from '../core/module.models';
import { ModuleService } from '../core/module.service';
import { ShellComponent } from '../shared/shell.component';

@Component({
  standalone: true,
  imports: [ShellComponent, RouterLink],
  template: `
    <sn-shell [title]="guild()?.name || 'Server'">
      @if (guild(); as item) {
        <div class="summary-grid">
          <div class="metric card">
            <span class="muted">Bot status</span>
            <strong>{{ item.bot_status }}</strong>
            <div class="status">Connected</div>
          </div>

          <div class="metric card">
            <span class="muted">Members</span>
            <strong>{{ item.member_count }}</strong>
            <small class="muted">Discord members</small>
          </div>

          <div class="metric card">
            <span class="muted">Your access</span>
            <strong>{{ item.access_role }}</strong>
            <small class="muted">ShieldNet role</small>
          </div>

          <div class="metric card">
            <span class="muted">Modules enabled</span>
            <strong>{{ enabledCount() }}/{{ modules().length }}</strong>
            <small class="muted">Server configuration</small>
          </div>
        </div>

        <div class="quick-grid">
          <a class="quick card" [routerLink]="['/guild', guildId, 'members']"><strong>Members Control Center</strong><span>Profiles, watchlist, cases and evidence</span></a>
          <a class="quick card" [routerLink]="['/guild', guildId, 'moderation']"><strong>Moderation Operations</strong><span>Queue, SLA, priorities and workload</span></a>
          <a class="quick card" [routerLink]="['/guild', guildId, 'audit']"><strong>Audit log</strong><span>Administrative activity and security events</span></a>
        </div>

        <div class="module-header">
          <div>
            <h2>Modules</h2>
            <p class="muted">
              Enable or disable functions separately for this Discord server.
            </p>
          </div>

          @if (savingKey()) {
            <div class="muted">Saving changes…</div>
          }
        </div>

        @if (error()) {
          <div class="error card">{{ error() }}</div>
        }

        @if (loading()) {
          <div class="loading card">Loading modules…</div>
        } @else {
          <div class="module-grid">
            @for (module of modules(); track module.module_key) {
              <article class="module card" [class.enabled]="module.enabled">
                <div class="module-icon">{{ module.icon || '◈' }}</div>

                <div class="module-content">
                  <div class="module-title">
                    <h3>{{ module.name }}</h3>

                    @if (module.is_core) {
                      <span class="badge core">Core</span>
                    } @else if (module.enabled) {
                      <span class="badge enabled-badge">Enabled</span>
                    } @else {
                      <span class="badge">Disabled</span>
                    }
                  </div>

                  <p class="muted">{{ module.description }}</p>

                  <div class="module-meta">
                    <span>v{{ module.version }}</span>
                    <span>Revision {{ module.revision }}</span>
                  </div>
                </div>

                <button
                  class="toggle"
                  [class.on]="module.enabled"
                  [disabled]="module.is_core || savingKey() === module.module_key"
                  (click)="toggle(module)"
                  [attr.aria-label]="'Toggle ' + module.name"
                >
                  <span></span>
                </button>
              </article>
            }
          </div>
        }
      } @else {
        <div class="card loading">Loading server…</div>
      }
    </sn-shell>
  `,
  styles: [`
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 1rem;
    }

    .metric {
      padding: 1.2rem;
      display: grid;
      gap: .45rem;
    }

    .metric strong {
      font-size: 1.55rem;
      text-transform: capitalize;
    }

    .quick-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:1rem; margin-top:1rem; }
    .quick { padding:1rem; display:grid; gap:.35rem; }
    .quick:hover { border-color:var(--primary); transform:translateY(-1px); }
    .quick span { color:var(--muted); font-size:.78rem; }

    .module-header {
      margin: 2rem 0 1rem;
      display: flex;
      align-items: end;
      justify-content: space-between;
      gap: 1rem;
    }

    .module-header h2,
    .module-header p {
      margin: 0;
    }

    .module-header p {
      margin-top: .35rem;
    }

    .module-grid {
      display: grid;
      gap: .8rem;
    }

    .module {
      padding: 1rem;
      display: grid;
      grid-template-columns: auto 1fr auto;
      gap: 1rem;
      align-items: center;
      transition: border-color .2s, transform .2s;
    }

    .module.enabled {
      border-color: rgba(75, 214, 155, .45);
    }

    .module:hover {
      transform: translateY(-1px);
    }

    .module-icon {
      width: 3rem;
      height: 3rem;
      border-radius: 14px;
      display: grid;
      place-items: center;
      background: var(--primary-soft);
      font-size: 1.25rem;
    }

    .module-title {
      display: flex;
      align-items: center;
      gap: .65rem;
      flex-wrap: wrap;
    }

    .module h3 {
      margin: 0;
    }

    .module p {
      margin: .35rem 0 0;
    }

    .module-meta {
      margin-top: .65rem;
      display: flex;
      gap: .8rem;
      color: var(--muted);
      font-size: .75rem;
    }

    .badge {
      padding: .22rem .52rem;
      border-radius: 999px;
      border: 1px solid var(--line);
      color: var(--muted);
      font-size: .7rem;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: .04em;
    }

    .badge.core {
      color: #cfd5ff;
      background: var(--primary-soft);
      border-color: rgba(104, 119, 255, .35);
    }

    .badge.enabled-badge {
      color: #b9f4dc;
      background: rgba(75, 214, 155, .12);
      border-color: rgba(75, 214, 155, .35);
    }

    .toggle {
      width: 3.1rem;
      height: 1.75rem;
      padding: .2rem;
      border-radius: 999px;
      background: #2a344b;
      transition: background .2s;
    }

    .toggle span {
      display: block;
      width: 1.35rem;
      height: 1.35rem;
      border-radius: 50%;
      background: white;
      transition: transform .2s;
    }

    .toggle.on {
      background: var(--success);
    }

    .toggle.on span {
      transform: translateX(1.35rem);
    }

    .toggle:disabled {
      opacity: .55;
      cursor: default;
    }

    .loading,
    .error {
      padding: 1.3rem;
    }

    .error {
      color: #ffd9de;
      border-color: rgba(255, 107, 125, .4);
    }

    @media (max-width: 900px) {
      .quick-grid { grid-template-columns:1fr; }
      .summary-grid {
        grid-template-columns: repeat(2, 1fr);
      }
    }

    @media (max-width: 600px) {
      .summary-grid {
        grid-template-columns: 1fr;
      }

      .module {
        grid-template-columns: auto 1fr;
      }

      .toggle {
        grid-column: 1 / -1;
        justify-self: end;
      }

      .quick-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:1rem; margin-top:1rem; }
    .quick { padding:1rem; display:grid; gap:.35rem; }
    .quick:hover { border-color:var(--primary); transform:translateY(-1px); }
    .quick span { color:var(--muted); font-size:.78rem; }

    .module-header {
        align-items: flex-start;
        flex-direction: column;
      }
    }
  `],
})
export class GuildComponent implements OnInit {
  readonly guilds = signal<GuildAccess[]>([]);
  readonly modules = signal<GuildModule[]>([]);
  readonly loading = signal(true);
  readonly savingKey = signal('');
  readonly error = signal('');

  readonly guildId = Number(
    this.route.snapshot.paramMap.get('guildId'),
  );

  readonly guild = computed(() =>
    this.guilds().find((item) => item.guild_id === this.guildId) || null,
  );

  readonly enabledCount = computed(() =>
    this.modules().filter((item) => item.enabled).length,
  );

  constructor(
    private readonly route: ActivatedRoute,
    private readonly guildService: GuildService,
    private readonly moduleService: ModuleService,
  ) {}

  async ngOnInit(): Promise<void> {
    try {
      const [guilds, modules] = await Promise.all([
        this.guildService.list(),
        this.moduleService.list(this.guildId),
      ]);

      this.guilds.set(guilds);
      this.modules.set(modules);
    } catch {
      this.error.set('Unable to load server modules.');
    } finally {
      this.loading.set(false);
    }
  }

  async toggle(module: GuildModule): Promise<void> {
    if (module.is_core || this.savingKey()) {
      return;
    }

    this.savingKey.set(module.module_key);
    this.error.set('');

    try {
      const updated = await this.moduleService.update(
        this.guildId,
        module.module_key,
        !module.enabled,
        module.configuration,
      );

      this.modules.update((items) =>
        items.map((item) =>
          item.module_key === updated.module_key
            ? updated
            : item,
        ),
      );
    } catch {
      this.error.set(`Unable to update ${module.name}.`);
    } finally {
      this.savingKey.set('');
    }
  }
}
